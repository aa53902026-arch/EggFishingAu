package com.example.eggfishingauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.NotificationChannel
import android.app.NotificationManager
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class FishingAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastTap = 0L
    private var lastRare = ""
    private val prefs by lazy { getSharedPreferences("fishing", MODE_PRIVATE) }
    private val loop = object : Runnable {
        override fun run() {
            if (prefs.getBoolean("enabled", false)) {
                val now = System.currentTimeMillis()
                val interval = prefs.getLong("interval", 1200L).coerceAtLeast(500L)
                if (now - lastTap >= interval) {
                    tap(prefs.getInt("x", 1100).toFloat(), prefs.getInt("y", 900).toFloat())
                    lastTap = now
                }
                scanForRare(rootInActiveWindow)
            }
            handler.postDelayed(this, 250L)
        }
    }
    override fun onServiceConnected() { super.onServiceConnected(); handler.post(loop); createChannel() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { if (prefs.getBoolean("enabled", false)) scanForRare(rootInActiveWindow) }
    override fun onInterrupt() { prefs.edit().putBoolean("enabled", false).apply() }
    override fun onDestroy() { handler.removeCallbacks(loop); super.onDestroy() }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 70)).build()
        dispatchGesture(gesture, null, null)
    }
    private fun scanForRare(node: AccessibilityNodeInfo?) {
        if (node == null) return
        val text = StringBuilder()
        collectText(node, text)
        val keywords = (prefs.getString("rare", "Jellynova,Legendary,Mythic") ?: "").split(',').map { it.trim() }.filter { it.isNotEmpty() }
        val found = keywords.firstOrNull { text.contains(it, ignoreCase = true) }
        if (found != null && found != lastRare) {
            lastRare = found
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val notification = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, "rare_fish") else android.app.Notification.Builder(this)
            notification.setSmallIcon(android.R.drawable.star_big_on).setContentTitle("희귀 획득 감지").setContentText("화면에서 '$found' 문구를 찾았어요. 자동 낚시는 계속됩니다.").setAutoCancel(true)
            nm.notify(42, notification.build())
            Toast.makeText(this, "희귀 획득 감지: $found", Toast.LENGTH_LONG).show()
        }
        if (found == null) lastRare = ""
    }
    private fun collectText(node: AccessibilityNodeInfo, out: StringBuilder) {
        node.text?.let { out.append(it).append(' ') }
        node.contentDescription?.let { out.append(it).append(' ') }
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectText(it, out) }
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("rare_fish", "희귀 획득 알림", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }
}
