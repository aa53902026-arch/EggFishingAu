package com.example.eggfishingauto

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("fishing", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 36, 28, 24) }
        root.addView(TextView(this).apply { text = "Egg Fishing Auto · 테스트 버전"; textSize = 22f })
        root.addView(TextView(this).apply { text = "영상 속 게임은 화면 요소가 게임 엔진 안에 그려져 있어, 이 버전은 지정한 위치를 반복 탭하고 접근성 텍스트에서 희귀 이름을 찾는 프로토타입입니다.\n\n먼저 아래에서 화면 좌표를 직접 설정하세요."; textSize = 14f; setPadding(0, 16, 0, 18) })
        val x = field("탭 X 좌표(px)", prefs.getInt("x", 1100).toString())
        val y = field("탭 Y 좌표(px)", prefs.getInt("y", 900).toString())
        val interval = field("탭 간격(ms, 최소 500)", prefs.getLong("interval", 1200L).toString())
        val rare = field("희귀 이름 키워드(쉼표로 구분)", prefs.getString("rare", "Jellynova,Legendary,Mythic") ?: "Jellynova,Legendary,Mythic")
        listOf(x,y,interval,rare).forEach { root.addView(it) }
        val save = Button(this).apply { text = "설정 저장"; setOnClickListener {
            prefs.edit().putInt("x", x.text.toString().toIntOrNull() ?: 1100)
                .putInt("y", y.text.toString().toIntOrNull() ?: 900)
                .putLong("interval", (interval.text.toString().toLongOrNull() ?: 1200L).coerceAtLeast(500L))
                .putString("rare", rare.text.toString()).apply()
            Toast.makeText(this@MainActivity, "저장했어요", Toast.LENGTH_SHORT).show()
        } }
        root.addView(save)
        root.addView(Button(this).apply { text = "접근성 권한 설정 열기"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(Button(this).apply { text = "자동 낚시 시작"; setOnClickListener { prefs.edit().putBoolean("enabled", true).apply(); Toast.makeText(this@MainActivity, "서비스가 켜져 있으면 자동 탭을 시작합니다", Toast.LENGTH_LONG).show() } })
        root.addView(Button(this).apply { text = "자동 낚시 정지"; setOnClickListener { prefs.edit().putBoolean("enabled", false).apply(); Toast.makeText(this@MainActivity, "정지 요청 완료", Toast.LENGTH_SHORT).show() } })
        root.addView(TextView(this).apply { text = "주의: 게임의 이용 규칙을 확인하고 사용하세요. 이 앱은 화면 전체를 이해하는 AI가 아니며, 낚시 게이지의 움직임이나 성공 여부를 정확히 판별하지 못할 수 있습니다. 좌표를 잘못 입력하면 엉뚱한 곳을 누를 수 있습니다."; textSize = 13f; setPadding(0, 18, 0, 0) })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun field(label: String, value: String): EditText = EditText(this).apply { hint = label; setText(value); textSize = 15f }
}
